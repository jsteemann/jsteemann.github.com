filelist
========

An example ArangoDB-Foxx application for handling binary data.

The application provides a server-side filelist that is 
accessible via the following REST API:
* `GET /list`: lists all files
* `GET /fetch/:file`: returns contents of the specified file
* `POST /store`: stores a file on the server

