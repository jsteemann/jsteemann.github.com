/*global require, applicationContext */
(function () {
  'use strict';
  var db = require('org/arangodb').db,
    fs = require("fs"),
    directory = applicationContext.foxxFilename("files"),
    collectionName = applicationContext.collectionName('filelist');

  if (db._collection(collectionName) === null) {
    db._create(collectionName);
  }

  if (! fs.isDirectory(directory)) {
    fs.makeDirectory(directory);
  }
}());
